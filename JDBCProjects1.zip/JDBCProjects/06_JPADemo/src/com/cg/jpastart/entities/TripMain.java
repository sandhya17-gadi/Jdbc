package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TripMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SeatInfo seat=new SeatInfo(15,20,18);
		Trip trip=new Trip();
		trip.setFromCity("chennai");
		trip.setToCity("mumbai");
		trip.setInfo(seat);
		
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(trip);
		em.getTransaction().commit();
		em.close();
		factory.close();
		
		

	}

}
