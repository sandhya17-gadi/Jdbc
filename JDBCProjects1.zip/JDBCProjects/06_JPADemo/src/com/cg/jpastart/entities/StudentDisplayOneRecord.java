package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StudentDisplayOneRecord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Student student=null;
		em.getTransaction().begin();
		student=em.find(Student.class, 1);
		System.out.println(student);
		
		
		em.getTransaction().commit();
		em.close();
		factory.close();

	}

}
