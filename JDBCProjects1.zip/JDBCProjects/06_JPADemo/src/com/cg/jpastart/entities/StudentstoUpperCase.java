package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentstoUpperCase {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Student student=null;
		//em.getTransaction().begin();
		String myQuery="from Student";
		Query query=em.createQuery(myQuery);
		List<Student> stuList=null;
		stuList=query.getResultList();
		String str="";
		 for (Student s : stuList) {
			
			 str=s.getName().toUpperCase();
			 s.setName(str);
			 System.out.println(str);
			 em.getTransaction().begin();
			 em.merge(s);
			 em.getTransaction().commit();
		}
		 
		 
		// em.getTransaction().commit();
		 em.close();
		 factory.close();
		
		
	}

}
