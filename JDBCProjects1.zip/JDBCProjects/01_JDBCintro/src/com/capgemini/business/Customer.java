package com.capgemini.business;

public class Customer {
	
	private int id;
	private String name;
	private String cityt;
	private double outStandingAmount;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		if(id<0)
		{
			throw new RuntimeException("Invali id");
			
		}
		this.id = id;
	}
	public String getName() {
		
		return name.toUpperCase();
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCityt() {
		return cityt;
	}
	public void setCityt(String cityt) {
		this.cityt = cityt;
	}
	public double getOutStandingAmount() {
		return outStandingAmount;
	}
	public void setOutStandingAmount(double outStandingAmount) {
		this.outStandingAmount = outStandingAmount;
	}
	
	
	public String getCustomerRating()
	{
		if(this.outStandingAmount < 5000)
		{
			return "GOOD";
		}
		else
		{
			return "NORMAL";
		}
		
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", cityt=" + cityt
				+ ", outStandingAmount=" + outStandingAmount + "]";
	}
	
	
	
	

}
