package com.capgemini.ui;


import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.business.Customer;
import com.capgemini.db.CustomerDAOImpl;
import com.capgemini.db.ICustomerDAO;

public class Main {
	
	
      public static void add() throws ClassNotFoundException, SQLException
      {
    	  int id=0;
    	  String name="";
    	  String city="";
    	  double amt=0.0;
    	  Customer customer=new Customer();
    	  ICustomerDAO dao=new CustomerDAOImpl();
    	  Scanner scanner=new Scanner(System.in);
    	  System.out.println("Enter id: ");
    	  id=scanner.nextInt();
    	  System.out.println("Enter name: ");
    	  name=scanner.next();
    	  System.out.println("Enter city: ");
    	  city=scanner.next();
    	  System.out.println("Enter amount: ");
    	  amt=scanner.nextDouble();
    	  customer.setId(id);
    	  customer.setName(name);
          customer.setCityt(city);
          customer.setOutStandingAmount(amt);
          boolean result=dao.addCustomer(customer);
          if(result)
          {
        	  System.out.println("added successfully");
          }
          else
          {
        	  System.out.println("not added");
          }
          
          
    	  
    	  
    	   
      }
      public static void update() throws ClassNotFoundException, SQLException
      {
    	  int id=0;
    	  String name="";
    	  String city="";
    	  double amt=0.0;
    	  Customer customer=new Customer();
    	  ICustomerDAO dao=new CustomerDAOImpl();
    	  Scanner scanner=new Scanner(System.in);
    	  System.out.println("Enter id to modify: ");
    	  id=scanner.nextInt();
    	  System.out.println("Enter name: ");
    	  name=scanner.next();
    	  System.out.println("Enter city: ");
    	  city=scanner.next();
    	  System.out.println("Enter amount: ");
    	  amt=scanner.nextDouble();
    	  customer.setId(id);
    	  customer.setName(name);
          customer.setCityt(city);
          customer.setOutStandingAmount(amt);
          boolean result=dao.updateCustomer(customer);
          if(result)
          {
        	  System.out.println("updated successfully");
          }
          else
          {
        	  System.out.println("not updated");
        	  		
          }
          
    	  
    	  
      }
      public static void displayAll() throws ClassNotFoundException, SQLException
      {
    	  
    	  ICustomerDAO dao=new CustomerDAOImpl();
    	  List<Customer> customerList=dao.getAllCustomers();
    	  //System.out.println(customerList);
    	  for(Customer customer:customerList)
    	  {
    		  System.out.print(customer.getId()+" ");
    		  System.out.print(customer.getName()+"  ");
    		  System.out.print(customer.getCityt()+"  ");
    		  System.out.println(customer.getOutStandingAmount());
    		  
    	  }
    	  
    	  
    	  
      }
      public static void remove() throws ClassNotFoundException, SQLException
      {
    	  int inp_id=0;
    	  Scanner scanner=new Scanner(System.in);
    	  System.out.println("Enter id to remove");
    	  inp_id=scanner.nextInt();
    	  
    	  
          ICustomerDAO dao=new CustomerDAOImpl();
          boolean result=dao.removeCustomer(inp_id);
          if(result==true)
          {
        	  System.out.println("record deleted successfuly.....");
          }
    	  
    	  
      }
    
	
	
	
	
	
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		System.out.println("Customer Application");
		System.out.println("---------------------");
		System.out.println("1.Add new Customer");
		System.out.println("2.update Customer");
		System.out.println("3.Display all Customers");
		System.out.println("4.DeleteCustomer");
		System.out.println("5.Exit");
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter choice....");
		int choice=scanner.nextInt();
		switch (choice) {
			 case 1:add();
				
				     break;
	         case 2:update();
				
				     break;
	         case 3:displayAll();
				
				     break;
	         case 4:remove();
				
				     break;
	         case 5:System.out.println("*******Thank you*********");
				
				     break;
		
		}

	}

}
