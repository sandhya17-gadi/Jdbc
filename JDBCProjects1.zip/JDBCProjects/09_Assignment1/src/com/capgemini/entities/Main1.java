package com.capgemini.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
       Qualification qualification=new Qualification("M.B.B.S",5);
       Doctor doctor=new Doctor();
       doctor.setName("Sandhya");
      // doctor.setDoctorId(1217);
       doctor.setFee(200);
       doctor.setQual(qualification);
       
       
       EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
       EntityManager em=emf.createEntityManager();
       em.getTransaction().begin();
       em.persist(doctor);
       em.getTransaction().commit();
       em.close();
       emf.close();
    	   
	}

}
