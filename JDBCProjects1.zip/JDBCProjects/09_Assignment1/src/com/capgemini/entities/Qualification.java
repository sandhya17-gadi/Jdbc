package com.capgemini.entities;

import javax.persistence.Embeddable;

@Embeddable
public class Qualification {
    String nameOfQual;
    int experience;
    
    
    
	public Qualification() {
		super();
	}
	public Qualification(String nameOfQual, int experience) {
		super();
		this.nameOfQual = nameOfQual;
		this.experience = experience;
	}
	public String getNameOfQual() {
		return nameOfQual;
	}
	public void setNameOfQual(String nameOfQual) {
		this.nameOfQual = nameOfQual;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	@Override
	public String toString() {
		return "Qualification [nameOfQual=" + nameOfQual + ", experience="
				+ experience + "]";
	}
	
    
}
