package com.capgemini.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Feedetails fee=em.find(Feedetails.class, 1);
		System.out.println(fee.getFid()+" "+fee.getToni()+" "+fee.getTotalFee());
		Course course=em.find(Course.class, 1);
		System.out.println(course.getFeed().getFid()+" "+course.getFeed().getToni()+" "+course.getFeed().getTotalFee()+""+course.getCid()+" "+course.getCourseName());
		em.getTransaction().commit();
		em.close();
		factory.close();
	
		
		
		

	}

}
