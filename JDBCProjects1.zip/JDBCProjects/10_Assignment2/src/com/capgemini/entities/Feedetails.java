package com.capgemini.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Feedetails {
      
	 @Id
	 @Column(name="fee_id")
	 @GeneratedValue(strategy=GenerationType.AUTO)
	  private int fid;
	
	  @Column(name="Total_fee")
	  private double totalFee;
	  @Column(name="total_installments")
	  private int toni;
	  
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public double getTotalFee() {
		return totalFee;
	}
	public void setTotalFee(double totalFee) {
		this.totalFee = totalFee;
	}
	public int getToni() {
		return toni;
	}
	public void setToni(int toni) {
		this.toni = toni;
	}
	@Override
	public String toString() {
		return "Feedetails [fid=" + fid + ", totalFee=" + totalFee + ", toni="
				+ toni + "]";
	}
	  
	
}
