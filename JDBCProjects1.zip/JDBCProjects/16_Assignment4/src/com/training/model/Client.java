package com.training.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		
		Loan loan=new Loan();
		loan.setLoanId(1);
		loan.setLoanAmt(100000);
		loan.setCustomerName("Kiranmayi");
		
		Repayment repayment1=new Repayment();
		repayment1.setRid(1);
		repayment1.setrAmt(1000);
		repayment1.setInstallmentNo(2);
		
		Repayment repayment2=new Repayment();
		repayment2.setRid(2);
		repayment2.setrAmt(2000);
		repayment2.setInstallmentNo(2);
		
		loan.addRepayment(repayment1);
		loan.addRepayment(repayment2);
		
		em.persist(loan);
		
		System.out.println("Added to database");
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		

	}

}
