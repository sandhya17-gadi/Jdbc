package com.training.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;


@Entity
@Table(name="Repayment_master")
	
public class Repayment {
     
	@Id
	private int rid;
	private double rAmt;
	private int installmentNo;
	public Repayment(int rid, double rAmt, int installmentNo) {
		super();
		this.rid = rid;
		this.rAmt = rAmt;
		this.installmentNo = installmentNo;
	}
	
	public Repayment() {
		super();
	}

	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public double getrAmt() {
		return rAmt;
	}
	public void setrAmt(double rAmt) {
		this.rAmt = rAmt;
	}
	public int getInstallmentNo() {
		return installmentNo;
	}
	public void setInstallmentNo(int installmentNo) {
		this.installmentNo = installmentNo;
	}

	@Override
	public String toString() {
		return "Repayment [rid=" + rid + ", rAmt=" + rAmt + ", installmentNo="
				+ installmentNo + "]";
	}
	
	
    
}
