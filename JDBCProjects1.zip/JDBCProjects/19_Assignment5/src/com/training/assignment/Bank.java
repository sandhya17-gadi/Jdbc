package com.training.assignment;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Customer_master")
public class Bank {
	
	@Id
	private int bid;
	private String vname;
	private String location;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Customer_Bank", joinColumns = { @JoinColumn(name = "bid") }, inverseJoinColumns = { @JoinColumn(name = "id") })
	private List<Customer> custList=new ArrayList<Customer>();
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<Customer> getCustList() {
		return custList;
	}
	public void setCustList(List<Customer> custList) {
		this.custList = custList;
	}
	public void addCustomer(Customer c)
	{
		this.custList.add(c);
	}
	

}
