package com.training.assignment;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		Customer customer1=new  Customer();
		customer1.setId(1);
		customer1.setName("sdsfdf");
		customer1.setDob(new Date());
		
		Customer customer2=new  Customer();
		customer2.setId(2);
		customer2.setName("uuiksfdf");
		customer2.setDob(new Date());
		
		Customer customer3=new  Customer();
		customer3.setId(3);
		customer3.setName("rrtiksfdf");
		customer3.setDob(new Date());
		
		Customer customer4=new  Customer();
		customer4.setId(4);
		customer4.setName("uuijsfdf");
		customer4.setDob(new Date());
		
		Customer customer5=new  Customer();
		customer5.setId(5);
		customer5.setName("uunjlsfdf");
		customer5.setDob(new Date());
		
		Customer customer6=new  Customer();
		customer6.setId(6);
		customer6.setName("ghbiksfdf");
		customer6.setDob(new Date());
        
		Customer customer7=new  Customer();
		customer7.setId(7);
		customer7.setName("bbbksfdf");
		customer7.setDob(new Date());

		Customer customer8=new  Customer();
		customer8.setId(8);
		customer8.setName("ghaiksfdf");
		customer8.setDob(new Date());
		
		Customer customer9=new  Customer();
		customer9.setId(9);
		customer9.setName("bbbbiksfdf");
		customer9.setDob(new Date());
		
		Customer customer10=new  Customer();
		customer10.setId(10);
		customer10.setName("uuiksfdf");
		customer10.setDob(new Date());
		
		
		Bank bank1=new Bank();
		bank1.setBid(1);
		bank1.setVname("aaaaa");
		bank1.setLocation("chennai");
		
		bank1.addCustomer(customer1);
		bank1.addCustomer(customer7);
		bank1.addCustomer(customer4);
		
		customer1.addBank(bank1);
		customer7.addBank(bank1);
		customer4.addBank(bank1);
		
		
		Bank bank2=new Bank();
		bank2.setBid(2);
		bank2.setVname("bbbbb");
		bank2.setLocation("Hyderabad");
		
		bank2.addCustomer(customer6);
		bank2.addCustomer(customer1);
		bank2.addCustomer(customer4);
		
		customer6.addBank(bank2);
		customer1.addBank(bank2);
		customer4.addBank(bank2);
		
		
		Bank bank3=new Bank();
		bank3.setBid(3);
		bank3.setVname("ccccccb");
		bank3.setLocation("pune");
		
		bank3.addCustomer(customer3);
		bank3.addCustomer(customer6);
		bank3.addCustomer(customer9);
		
		customer3.addBank(bank3);
	    customer6.addBank(bank3);
	    customer9.addBank(bank3);
		
		Bank bank4=new Bank();
		bank4.setBid(4);
		bank4.setVname("dddddb");
		bank4.setLocation("Mumbai");
		
		bank4.addCustomer(customer10);
		bank4.addCustomer(customer5);
		bank4.addCustomer(customer2);
		
		customer10.addBank(bank4);
		customer5.addBank(bank4);
		customer2.addBank(bank4);
		
		Bank bank5=new Bank();
		bank5.setBid(5);
		bank5.setVname("eeeee");
		bank5.setLocation("Mumbai1");
		
		bank5.addCustomer(customer8);
		bank5.addCustomer(customer5);
		
		
		customer8.addBank(bank5);
		customer5.addBank(bank5);
		
		
		
		em.persist(bank1);
		em.persist(bank2);
		em.persist(bank3);
		em.persist(bank4);
		em.persist(bank5);
		
		System.out.println("Added to Database");
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		
		
		
		
		
		
		
		

	}

}
