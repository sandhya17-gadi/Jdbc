package com.training.client;


@Table(name="customer")
@Entity
public class Customer {
	
	@Id
	int id;
	
	@Column(name="name",size=25,notNull=true)
	String name;
	
	@Column(name="Hyderabad",size=30,notNull=true)
	String city;
	
	double outStandingAmount;
	

}
