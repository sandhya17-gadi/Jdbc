package com.training.client;



/** @author sagadi**/

public class Test4 {
	/** @param  n number to be computed for square  
	 * @return returns square of number **/
	int square(int n)
	{
		return n*n;
	}

}
