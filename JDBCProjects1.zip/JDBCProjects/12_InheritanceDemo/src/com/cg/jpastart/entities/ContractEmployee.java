package com.cg.jpastart.entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("CE")
public class ContractEmployee extends Employee {
	
	private int duration;
	private boolean extentable;
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public boolean isExtentable() {
		return extentable;
	}
	public void setExtentable(boolean extentable) {
		this.extentable = extentable;
	}
	@Override
	public String toString() {
		return "ContractEmployee [duration=" + duration + ", extentable="
				+ extentable + ", getEmployeeId()=" + getEmployeeId()
				+ ", getName()=" + getName() + ", getSalary()=" + getSalary()
				+ "]";
	}
	
	
	
	

}
