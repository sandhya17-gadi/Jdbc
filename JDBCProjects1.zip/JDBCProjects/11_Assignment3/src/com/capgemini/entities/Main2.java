package com.capgemini.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.print.attribute.standard.Finishings;

import oracle.net.aso.p;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		
		
		Course course=em.find(Course.class, 1);
		System.out.println(course.getCid()+" "+course.getCourseName()+" "+course.getFeeDetails().getFid()+" "+course.getFeeDetails().getNoInstall()+" "+course.getFeeDetails().getTotalFee());
		

		FeeDetails fd=em.find(FeeDetails.class, 1);
		
		
		System.out.println(fd.getFid()+" "+fd.getNoInstall()+" "+fd.getTotalFee()+" "+fd.getCourse().getCid()+" "+fd.getCourse().getCourseName()+" "+fd.getCourse().getFeeDetails().getFid());
		
		
		em.close();
		emf.close();
		
		
		  
		

	}

}
