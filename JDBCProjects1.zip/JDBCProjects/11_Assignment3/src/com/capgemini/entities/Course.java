package com.capgemini.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Course1")
public class Course {
	
	       @Id
	       @GeneratedValue(strategy=GenerationType.AUTO)
           private int cid;
	       
           private String courseName;
           
           
           @OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
        	@JoinColumn(name="fid")
           private FeeDetails feeDetails;
           
           
           
		public int getCid() {
			return cid;
		}
		public void setCid(int cid) {
			this.cid = cid;
		}
		public String getCourseName() {
			return courseName;
		}
		public void setCourseName(String courseName) {
			this.courseName = courseName;
		}
		public FeeDetails getFeeDetails() {
			return feeDetails;
		}
		public void setFeeDetails(FeeDetails feeDetails) {
			this.feeDetails = feeDetails;
		}
		
		
		
		
		
		
		
		/*@Override
		public String toString() {
			return "Course [cid=" + cid + ", courseName=" + courseName
					+ ", feeDetails=" + feeDetails + "]";
		}*/
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + cid;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Course other = (Course) obj;
			if (cid != other.cid)
				return false;
			return true;
		}
           
		
		
           
           
           
}
