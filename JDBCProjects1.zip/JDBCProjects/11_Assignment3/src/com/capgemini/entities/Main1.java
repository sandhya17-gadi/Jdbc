package com.capgemini.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		Course course=new Course();
		course.setCourseName("Java");
		
		
		FeeDetails fd=new FeeDetails();
		fd.setNoInstall(3);
		fd.setTotalFee(1000);
		course.setFeeDetails(fd);
		
		
		fd.setCourse(course);
		
		
		em.persist(course);
		em.persist(fd);
		
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();

	}

}
