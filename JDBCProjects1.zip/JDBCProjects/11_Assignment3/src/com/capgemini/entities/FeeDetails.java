package com.capgemini.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
 @Entity
 @Table(name="feedetails1")
public class FeeDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int fid;
	
	@Column(name="Total_fee")
	private double totalFee;
	
	@Column(name="Total_installments")
	private int noInstall;
	
	@OneToOne(mappedBy="feeDetails")
	private Course course;
	
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public double getTotalFee() {
		return totalFee;
	}
	public void setTotalFee(double totalFee) {
		this.totalFee = totalFee;
	}
	public int getNoInstall() {
		return noInstall;
	}
	public void setNoInstall(int noInstall) {
		this.noInstall = noInstall;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	/*@Override
	public String toString() {
		return "FeeDetails [fid=" + fid + ", totalFee=" + totalFee
				+ ", noInstall=" + noInstall + ", course=" + course + "]";
	}
	*/
	
	
	

}
