package com.training.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main1 {
	
	public static void main(String[] args) {
		
		String jpql="select p from Person p where p.salary >:startRange and p.salary <:endRange";
		
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		Query query=em.createQuery(jpql);
		
		query.setParameter("startRange", 24000.00);
		query.setParameter("endRange", 35000.00);
		
		
		
		
		List<Person> persons=query.getResultList();
		for (Person person : persons) {
			System.out.print(person.getPersonId());
			System.out.print(person.getName());
			System.out.print(person.getAge());
			System.out.print(person.getSalary());
			System.out.println(person.getGender());
			
		}
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
		
	}

}
