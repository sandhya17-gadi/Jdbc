package com.training.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person p1=new Person("Sandhya", 22, 20000, 'F');
		Person p2=new Person("Sandyy", 25, 25000, 'F');
		Person p3=new Person("Surya", 28, 30000, 'M');
		Person p4=new Person("Samyu", 26, 22000, 'M');
		Person p5=new Person("Sanju", 23, 22000, 'M');
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		em.persist(p1);
		em.persist(p2);
		em.persist(p3);
		em.persist(p4);
		em.persist(p5);
		em.getTransaction().commit();
		em.close();
		emf.close();
		
		
		
		

	}

}
