package com.training.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		Query query=em.createNamedQuery("salaryFilterQuery");
		
		query.setParameter("startRange", 24000.00);
		query.setParameter("endRange", 35000.00);
		
		List<Person> persons=query.getResultList();
		for (Person person : persons) {
			System.out.print(person.getPersonId()+" ");
			System.out.print(person.getName()+" ");
			System.out.print(person.getAge()+" ");
			System.out.print(person.getSalary()+" ");
			System.out.println(person.getGender());
			
		}
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();
		

	}

}
